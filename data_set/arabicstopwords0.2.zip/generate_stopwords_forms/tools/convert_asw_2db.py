﻿from pysqlite2 import dbapi2 as sqlite
import os
import sys
##from ar_ctype import *
def chomp(s):
  if (s.endswith('\n')):
    return s[:-1]
  else:
    return s
#-------------------------
#  Parameters
FILE_DATA=u"../data/stopwords_allforms.txt"
FILE_DB=u"../data/stopwords.db"
DB_CREATE_SQL=u'''create TABLE STOPWORDS
    (
    ID INT UNIQUE NOT NULL,
    WORD TEXT NOT NULL,
    STEMMEDWORD TEXT NOT NULL
    )
'''
NB_FIELD_MAX=2
SEPARATOR=u"\t"


#-------------------------------------
# create database file for
#------------------------------------
def create_database():
    liste=[];
    conn = sqlite.connect(FILE_DB)
    c = conn.cursor()

    sql = DB_CREATE_SQL;
    c.execute(sql)
    c.close();

#-------------------------------------
# test select
#------------------------------------
def test_select(word):
    liste=[];
    conn = sqlite.connect(FILE_DB)
    c = conn.cursor()
    t=(word,)
    sql = u"select id, WORD, STEMMEDWORD FROM STOPWORDS WHERE WORD ='%s'"%word
    c.execute(sql)
    list_words=[];
    for row in c:
        foundword=row[1]
        stemmedword=row[2]
        list_words.append((foundword, stemmedword));
        print u"| ".join([foundword, stemmedword]);
    c.close();
    return list_words;



#---------------------------------
# main readfile
#---------------------------------
def import_file():
	filename=FILE_DATA;
	try:
		fl=open(filename);
	except:
		print " Error :No such file or directory: %s" % filename
		sys.exit(0)
	line=fl.readline().decode("utf");
	text=u""
	tuple_table=[];
	nb_field=NB_FIELD_MAX;
	while line :
		if not line.startswith("#"):
			text=text+" "+chomp(line)
			line=line.strip('\n')
			liste=line.split(SEPARATOR);
			if len(liste)>=nb_field:
				tuple_table.append(liste);

		line=fl.readline().decode("utf");
	fl.close();

	id=0;
    #connection
	conn = sqlite.connect(FILE_DB)
	c = conn.cursor()
    #--------------------
    # query
    #--------------------
	limit=100000;
	for i in range(min(limit,len(tuple_table))):

#------------------------------------------------------
# treat data
#------------------------------------------------------
	    tup=tuple_table[i];
	    word=tup[0];
	    stemmed=tup[1];
	    id=i+1;# to avoid zero

	    t=(id, word, stemmed)
       # Insert a row of data
	    c.execute("""insert into STOPWORDS
          values (?,?,?)""",t)

#---------End treat data ------------------
    #commit
	conn.commit()
    #close
	c.close()
##	    print;




if __name__ == "__main__":
#  main()
#To create table
    create_database();
###To load info from csv file to db
    import_file();
#select
    word=u"معنا"
    list_words=test_select(word)
    if list_words:
        print "ok"
    else:
        print "no";


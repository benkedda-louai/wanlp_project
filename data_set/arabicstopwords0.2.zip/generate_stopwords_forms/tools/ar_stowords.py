#!/usr/bin/python
# -*- coding=utf-8 -*-
#
import re, string,sys
from arabic_const import *

def chomp(s):
  if (s.endswith('\n')):
    return s[:-1]
  else:
    return s

#-----------------------------------------------
#
#
#-----------------------------------------------
pronouns=(
u"%s"%YEH,
u"%s"%KAF,
u"%s"%HEH,
u"%s%s"%(KAF,MEEM),
u"%s%s"%(KAF,NOON),
u"%s%s"%(HEH,ALEF),
u"%s%s"%(HEH,MEEM),
u"%s%s"%(HEH,NOON),
u"%s%s"%(NOON,ALEF),
u"%s%s%s"%(KAF,MEEM,ALEF),
u"%s%s%s"%(HEH,MEEM,ALEF),
);
jonction=(u"%s"%WAW,u"%s"%FEH);
prepositions=(u"%s"%BEH,u"%s"%KAF);
definition=(u"%s%s"%(ALEF,LAM));

def generate_allforms(word,has_pronouns,has_jonction,has_preposition,has_definition,has_interrog):
    list_idafa=[word];
    if has_pronouns:
        for p in pronouns:
    # convert ALEF_mAKSURA to YEH
            list_idafa.append(word+"-"+p);
    if has_definition:
        list_idafa.append(ALEF+LAM+"-"+word)
    list2=[]
    if has_preposition :
        for w in list_idafa:
            list2.append(w)
            for pr in prepositions:
                list2.append(pr+"-"+w);
    else:
        list2=list_idafa;
    list3=[]
    if has_jonction :
        for w in list2:
            list3.append(w)
            for jo in jonction:
                list3.append(jo+"-"+w);
    list4=[]
    if has_interrog :
        for w in list3:
            list4.append(w)
            list4.append(ALEF_HAMZA_ABOVE+"-"+w);
    else:
        list4=list3;
    return list4;


def standardize_form(word):
    word=re.sub(u"%s-"%ALEF_MAKSURA,YEH,word)
    word=re.sub(u"%s-"%TEH_MARBUTA,TEH,word)
    word=re.sub(u"-",'', word);
    return word;
#!/usr/bin/python
# -*- coding=utf-8 -*-
#************************************************************************
# $Id: ar_ctype.py,v 0.7 2009/06/02 01:10:00 Taha Zerrouki $
#
# ------------
# Description:
# ------------
#  Copyright (c) 2009, Arabtechies, Arabeyes Taha Zerrouki
#
#  Elementary function to manipulate arabic texte
#
# -----------------
# Revision Details:    (Updated by Revision Control System)
# -----------------
#  $Date: 2009/06/02 01:10:00 $
#  $Author: Taha Zerrouki $
#  $Revision: 0.7 $
#  $Source: arabtechies.sourceforge.net
#
#***********************************************************************/

import re, string,sys
import types
from arabic_const import *
##from verb_const import *

#!/usr/bin/python
# -*- coding=utf-8 -*-
#---

#--------------------------------------
def replace_pos (word,rep, pos):
	return word[0:pos]+rep+word[pos+1:];
#--------------------------------------
def chomp(s):
  if (s.endswith('\n')):
    return s[:-1]
  else:
    return s;
HARAKAT_pat =re.compile(ur"^[%s%s%s%s%s%s%s%s]$"%(FATHATAN,DAMMATAN,KASRATAN,FATHA,DAMMA,KASRA,SUKUN,SHADDA) )
HARAKAT_NO_SHADDA_pat =re.compile(ur"^[%s%s%s%s%s%s%s]$"%(FATHATAN,DAMMATAN,KASRATAN,FATHA,DAMMA,KASRA,SUKUN) )
#--------------------------------------
def ar_isvowel(w):
	" return True if the letter is an arabic vowel. SHADDA is  a vowel."
	res=HARAKAT_pat.match(w);
	if res:return True;
	else: return False;

# return True if the letter is a tatweel.
#--------------------------------------
def ar_istatweel(w):
	"return True if the letter is a tatweel."
	if w==TATWEEL :  return True;
	else :return False;

#--------------------------------------
def ar_strip_vowel(w):
	"strip vowel from a word and return a result word"
	return HARAKAT_pat.sub('', w)


#strip tatweel from a word and return a result word
#--------------------------------------
def ar_strip_tatweel(w):
	"strip tatweel from a word and return a result word"
	return re.sub(ur'[%s]' % TATWEEL,	'', w)

#strip tatweel and vowel from a word and return a result word but keep shadda
#--------------------------------------
def ar_strip_marks_keepshadda(w):
	return re.sub(ur'[%s%s%s%s%s%s%s%s]' % (FATHATAN, DAMMATAN, TATWEEL,
                                            KASRATAN, FATHA, DAMMA, KASRA, SUKUN),	'', w)


#strip tatweel and vowel from a word and return a result word
#--------------------------------------
def ar_strip_marks(w):
	"strip tatweel and vowel from a word and return a result word"
	return re.sub(ur'[%s%s%s%s%s%s%s%s%s]' % (FATHATAN, DAMMATAN, TATWEEL,
                                            KASRATAN, FATHA, DAMMA, KASRA, SUKUN,SHADDA),	'', w)



#strip pounctuation from the text
#--------------------------------------
def ar_strip_punct(w):
    return re.sub(r'[%s%s%s%s\\]' % (string.punctuation, string.digits,
                                     string.ascii_letters, string.whitespace),
                  ' ', w)
# return True if the given word have the same or the partial vocalisation like the pattern
#------------------------------------------------
def vocalizedlike( vocalized,word):
	vocalized=re.sub(u"[%s]"%FATHA,u"[%s]?"%FATHA,vocalized)
	vocalized=re.sub(u"[%s]"%KASRA,u"[%s]?"%KASRA,vocalized)
	vocalized=re.sub(u"[%s]"%DAMMA,u"[%s]?"%DAMMA,vocalized)
	vocalized=re.sub(u"[%s]"%SUKUN,u"[%s]?"%SUKUN,vocalized)
	vocalized=re.sub(u"[%s]"%SHADDA,u"[%s]?"%SHADDA,vocalized)
	vocalized="^"+vocalized+"$";
	pat=re.compile(vocalized);
	res=pat.match(word);
	if res : return True;
	else : return False;

# this function is to replace all letters non vowel to an unique symbole, to be used for test vowlization
#--------------------------------------
def replace_letters(word0):
	return re.sub(ur'[^%s%s%s%s%s%s%s%s]' % (FATHATAN, DAMMATAN, KASRATAN, FATHA, DAMMA, KASRA,
                                            SUKUN,SHADDA),	u'-', word0)
# للمقارنة بين كلمتين متساويتين في الطول إذا كانتا متشاكلتان: أي يتطابق تشكيلهما جزئيا أو كليا.
# لا يهم إن كانتا غير متساويتين في الحروف
# if verify_vowel_only is True: verify only the vowels
#else verify letters too,
#--------------------------------------
def equal_shakl(word0,wazn0,verify_vowel_only=False):
	if not verify_vowel_only :
		word=ar_strip_marks(word0);
		wazn=ar_strip_marks(wazn0);
		if word!=wazn : return False;
	else :
		if len(ar_strip_marks(word0))!=len(ar_strip_marks(wazn0)):
			return False;
		word=replace_letters(word0);
		wazn=replace_letters(wazn0);
	# j :word index
#	print 1;
	j=0;
	i=0;
	while i< len(wazn) and j<len(word):
#		print 2;
		wazn_i_isvowel=ar_isvowel(wazn[i]);
		word_j_isvowel=ar_isvowel(word[j]);
		if (wazn_i_isvowel) and (word_j_isvowel):
			if wazn[i]!=word[j]:
#				print 3;
				return False;
			else: j+=1;
		elif (wazn_i_isvowel) and (not word_j_isvowel):
#			print 4;
			pass;
		elif (not wazn_i_isvowel) and ( word_j_isvowel):
#			print 5;
			while (ar_isvowel(word[j])) :  j+=1;
			if  (wazn[i]!=word[j]): return False;
			else : j+=1;
		elif  (not wazn_i_isvowel) and (not word_j_isvowel):
			if wazn[i]!=word[j]:
#				print 7;
				return False;
			else: j+=1;
		i+=1;
		#strip last vowel
	while ( j<len(word) and ar_isvowel(word[j]) ):  j+=1;
	if(j<len(word)): return False;
	return True;

#--------------------------------------
#
#
#
#---------------------------------------
def is_valid_arabic_word(word):
    if len(word)==0: return False;
    word_nm=ar_strip_marks_keepshadda(word);
    # the alef_madda is  considered as 2 letters
    word_nm=word_nm.replace(ALEF_MADDA,HAMZA+ALEF);
    if word[0] in (WAW_HAMZA,YEH_HAMZA,FATHA,DAMMA,SUKUN,KASRA):
        return False;
#  إذا كانت الألف المقصورة في غير آخر الفعل
    if re.match(u"^(.)*[%s](.)+$"%ALEF_MAKSURA,word):
        return False;
    if re.match(u"^(.)*[%s]([^%s%s%s])(.)+$"%(TEH_MARBUTA,DAMMA,KASRA,FATHA),word):
        return False;
##    i=0;

    if not re.match(u"([\u0621-\u0652]|[%s%s%s])+"%(LAM_ALEF, LAM_ALEF_HAMZA_ABOVE,LAM_ALEF_MADDA_ABOVE),word):
        return False;
##    while i <len(word):
##    # خارج نطاق الحروف العربية الأساسية
##    # مابين الهمزة على السطر والسكون
##        if word[i]<u'\u0621' or (word[i]>u'\u0652' and word[i] not in (LAM_ALEF, LAM_ALEF_HAMZA_ABOVE,LAM_ALEF_MADDA_ABOVE)):
##            return False;
##        i+=1
    return True;


###--------------------------------------
###
###
###
###---------------------------------------
##def is_valid_infinitive_verb(word):
##### This function return True, if the word is valid, else, return False
##### A word is not valid if :
##### - minimal lenght : 3
##### - starts with :
#####    ALEF_MAKSURA, WAW_HAMZA,YEH_HAMZA,
#####    HARAKAT
##### - contains : TEH_MARBUTA
##### - contains  ALEF_MAKSURA at the began or middle.
##### - contains : double haraka : a warning
##### - contains: tanween
##    word_nm=ar_strip_marks_keepshadda(word);
##    # the alef_madda is  considered as 2 letters
##    word_nm=word_nm.replace(ALEF_MADDA,HAMZA+ALEF);
##    if len(word_nm)<3  or len(word_nm)>7: return False;
##    i=0;
##    while i <len(word):
##    # خارج نطاق الحروف العربية الأساسية
##    # مابين الهمزة على السطر والسكون
##
##        if word[i]<u'\u0621' or (word[i]>u'\u0652' and word[i] not in (LAM_ALEF, LAM_ALEF_HAMZA_ABOVE,LAM_ALEF_MADDA_ABOVE)):
##            return False;
##        elif word[i] in (ALEF_HAMZA_BELOW, TEH_MARBUTA,DAMMATAN,KASRATAN,FATHATAN):
##            return False;
##        else:
###  إذا كانت الألف المقصورة في غير آخر الفعل
##            if word[i]==ALEF_MAKSURA and i<len(word)-1:
##               return False;
##            elif word[0] in (WAW_HAMZA,YEH_HAMZA,FATHA,DAMMA,SUKUN,KASRA):
##               return False;
##
##        i+=1
###verify the wazn of the verb
##    if len(word_nm)==3:
##        if re.match("^[^%s][^%s].$"%(ALEF,SHADDA),word_nm):
##            return True;
### الأوزان المقبولة هي فعل، فعّ،
### الأوزان غير المقبولة
### اعل، فّل
##        else: return False;
##    if len(word_nm)==4:
####        if re.match("^([^%s%s][^%s][^%s]|[%s][^%s].)[^%s]$"%(ALEF,SHADDA,SHADDA,ALEF,ALEF_HAMZA_ABOVE,SHADDA,SHADDA),word_nm):
###---------------------1- أفعل، 2- فاعل، 3 فعّل 4 فعلل
##        if re.match("^(%s[^%s]{2}.|[^%s%s]%s[^%s%s].|[^%s%s]{2}%s[^%s]|[^%s%s]{4})$"%(ALEF_HAMZA_ABOVE,SHADDA,ALEF,SHADDA,ALEF,ALEF,SHADDA,ALEF,SHADDA,SHADDA,SHADDA,ALEF,SHADDA),word_nm):
##
##            return True;
### الأوزان المقبولة هي فعل، فعّ،
### الأوزان غير المقبولة
### افعل: يجب تثبيت همزة القطع
###فّعل، فعلّ: الشدة لها موضع خاص
### فعال، فعلا: للألف موضع خاص
##        else: return False;
##    if len(word_nm)==5:
##        if re.match(u"^(([^%s][^%s][^%s]|[^%s][^%s].).[^%s])|ت.يّا$"%(SHADDA,SHADDA,SHADDA,SHADDA,SHADDA,ALEF),word_nm):
##            return True;
### الأوزان المقبولة هي فعل، فعّ،
### الأوزان غير المقبولة
###للشدة موضع خاص: تفعّل، افتعّ
### للألف مواضع خاصة،
##        else: return False;
##    if len(word_nm)==6:
##        if re.match(u"^است...|ا..ن..|ا..و..|ا..ا.ّ|ا....ّ$",word_nm):
##            return True;
### الأوزان المقبولة هي فعل، فعّ،
### الأوزان غير المقبولة
###للشدة موضع خاص: تفعّل، افتعّ
### للألف مواضع خاصة،
##        else: return False;
##    return True;
##
###--------------------------------------
###  suggest many verb if the verb is invalid
###
###
###---------------------------------------
##def suggest_verb(verb):
### the verb is invalid
##    list_suggest=[];
##    verb=ar_strip_marks_keepshadda(verb);
##    verb=re.sub(u"[%s%s%s%s]"%( TEH_MARBUTA,DAMMATAN,KASRATAN,FATHATAN),'',verb)
##    if is_valid_infinitive_verb(verb):
##        list_suggest.append(verb);
##        return list_suggest;
##    elif verb.startswith(ALEF_HAMZA_BELOW):
##        verb=re.sub(ALEF_HAMZA_BELOW,ALEF,verb);
##        if is_valid_infinitive_verb(verb):
##            list_suggest.append(verb);
##            return list_suggest;
##    elif verb.startswith(ALEF):
##        verb_one=re.sub(ALEF,ALEF_HAMZA_ABOVE+FATHA,verb,1);
##        if is_valid_infinitive_verb(verb_one):
##            list_suggest.append(verb_one);
##            return list_suggest;
##    elif len(verb)==2:
##        verb=re.sub(ALEF,ALEF_HAMZA_ABOVE,verb,1);
##        verb_one=verb+SHADDA;
##        if is_valid_infinitive_verb(verb_one):
##            list_suggest.append(verb_one);
##        verb_one=verb+ALEF_MAKSURA;
##        if is_valid_infinitive_verb(verb_one):
##            list_suggest.append(verb_one);
##        verb_one=verb+ALEF;
##        if is_valid_infinitive_verb(verb_one):
##            list_suggest.append(verb_one);
##        verb_one=verb[0]+ALEF+verb[1];
##        if is_valid_infinitive_verb(verb_one):
##            list_suggest.append(verb_one);
##        return list_suggest;
##    elif len(verb)>=6:
##        for i in range(len(verb)-6):
##            verb_one=ALEF+verb[i:i+5];
##            if is_valid_infinitive_verb(verb_one):
##                list_suggest.append(verb_one);
##    elif len(verb)==5:
##        for i in range(len(verb)-5):
##            verb_one=ALEF+verb[i:i+4];
##            if is_valid_infinitive_verb(verb_one):
##                list_suggest.append(verb_one);
##    elif len(verb)==4:
##        if verb[2]==ALEF or verb[1]==SHADDA:
##            verb_one=verb[0]+verb[2]+verb[1]+verb[3]
##            if is_valid_infinitive_verb(verb_one):
##                list_suggest.append(verb_one);
##        if verb.endswith(SHADDA):
##            verb_one=verb[0]+verb[1]+verb[3]+verb[2]
##            if is_valid_infinitive_verb(verb_one):
##                list_suggest.append(verb_one);
##        return list_suggest;
##    else:
##        list_suggest.append(u"كتب");
##        return list_suggest;
##    return list_suggest;
##
##
##
##
### تحويل الكلمة إلى شكلها النظري.
### الشكل اللإملائي للكلمة هو طريقة كتابتها حسب قواعد الإملاء
### الشكل النظري هو الشكل المتخيل للكلمة دون تطبيق قواعد اللغة
### ويخص عادة الأشكال المتعددة للهمزة، و التي تكتب همزة على السطر
### أمثلة
### إملائي		نظري
###إِمْلَائِي		ءِمْلَاءِي
###سَاَلَ		سَءَلَ
### الهدف : تحويل الكلمة إلى شكل نظري، ومن ثم إمكانية تصريفها بعيدا عن قواعد الإملاء،
###وبعد التصريف يتم تطبيق قواعد الإملاء من جديد.
###الفرضية: الكلمات المدخلة مشكولة شكلا تاما.
###الطريقة:
### 1-تحويل جميع أنواع الهمزات إلى همزة على السطر
### 1-فك الإدغام
###--------------------------------------
###--------------------------------------
##
##def normalize(word,type="affix"):
####standardize the Hamzat into one form of hamza
#### replace shadda by double letters
#### replace Madda by hamza and alef.
#### replace the LamAlefs by simplified letters.
##
##	HAMZAT= u"إأءئؤ";
##	i=0;
###   strip tatweel
### the tatweel is used to uniformate the affix when the Haraka is used separetely
##	if type!="affix": word=ar_strip_tatweel(word);
#### تستبدل الألف الممدودة في ,ل الكلمة بهمزة قطع بعدها همزة أخرى
##	if word.startswith(ALEF_MADDA):
###TODO:
#### مشكلة في تحويل ألف المدة الأولى، فهي تنقلب إما إلى همزة بعدها أللف في مثل فاعل،
#### وذلك في حال الفعل المضعف مهموز الأول
#### أو همزتين متتاليتين على وزن أفعل
##	   if len(word)>=3 and (word[1] not in HARAKAT) and (word[2]==SHADDA or len(word)==3):
##			word=HAMZA+FATHA+ALEF+word[1:];
##	   else:
##			word=HAMZA+FATHA+HAMZA+SUKUN+word[1:];
#### ignore harakat at the began of the word
##	while word[i] in HARAKAT:
##		i+=1;
##	word=word[i:]
##
##	while i in range(len(word)):
#### حالة غياب الفتحة قبل الألف
##		if word[i] not in(SUKUN,FATHA,KASRA,DAMMA,ALEF) and i+1<len(word) and word[i+1]==ALEF:
##		  word=replace_pos(word,word[i]+FATHA,i);
##		if word[i] in HAMZAT:
##			word=replace_pos(word,HAMZA,i);
####		elif word[i]==SHADDA:
######			word=replace_pos(word,SUKUN+word[i-1],i)
####			word=replace_pos(word,SUKUN+word[i-1],i)
####  تستبدل المدة في وسط الكلمة بهمزة مفتوحة وألف
##		elif word[i]==ALEF_MADDA:
##			word=word.replace(ALEF_MADDA,HAMZA+FATHA+ALEF);
##		elif word[i]==LAM_ALEF:
##			word=word.replace(LAM_ALEF,simple_LAM_ALEF);
##		elif word[i]==LAM_ALEF_HAMZA_ABOVE:
##			word=word.replace(LAM_ALEF_HAMZA_ABOVE,simple_LAM_ALEF_HAMZA_ABOVE);
##		elif word[i]==LAM_ALEF_HAMZA_BELOW:
##			word=word.replace(LAM_ALEF_HAMZA_BELOW,simple_LAM_ALEF_HAMZA_BELOW);
##		elif word[i]==LAM_ALEF_MADDA_ABOVE:
##			word=word.replace(LAM_ALEF_MADDA_ABOVE,simple_LAM_ALEF_MADDA_ABOVE);
##		i+=1;
##	word=word.replace( u"%s"%(SHADDA),SUKUN+SHADDA);
##	return word;
###--------------------------------------
##def uniformate_alef_origin(marks,word_nm,future_type=KASRA):
##	if len(marks)!=2:return marks;
### الحرف الأخير علة
##	if marks[-1:]==ALEF_HARAKA:
##		if future_type==KASRA:
##			marks=marks[:-1]+ALEF_YEH_HARAKA;
##		elif future_type==DAMMA:
##			marks=marks[:-1]+ALEF_WAW_HARAKA;
### الحرف ماقبل الأخير علة
##	elif   marks[len(marks)-2]==ALEF_HARAKA:
##		if future_type==KASRA:
##			marks=marks[:-2]+ALEF_YEH_HARAKA+marks[-1:]
##		elif future_type==DAMMA:
##			marks=marks[:-2]+ALEF_WAW_HARAKA+marks[-1:]
### الحرف الأخير علة
##	if len(word_nm)==3 and word_nm[-1:]==ALEF:
##	    word_nm=word_nm[:-1]+WAW
##	elif len(word_nm)>3 and word_nm[-1:]==ALEF:
##	    word_nm=word_nm[:-1]+YEH
##	elif word_nm[-1:]==ALEF_MAKSURA:
##	    word_nm=word_nm[:-1]+YEH
##	return marks;
##
#####--------------------------------------
####def uniformate_last_alef(word_nm):
##### الحرف الأخير علة
####	if len(word_nm)==3 and word_nm[-1:]==ALEF:
####	    word_nm=word_nm[:-1]+WAW
####	elif len(word_nm)>3 and word_nm[-1:]==ALEF:
####	    word_nm=word_nm[:-1]+YEH
####	elif word_nm[-1:]==ALEF_MAKSURA:
####	    word_nm=word_nm[:-1]+YEH
####
####	return word_nm;
##
###--------------------------------------
##def uniformate2(word,type="affix"):
##	""" separate the harakat and the letters of the given word, it return two strings ( the word without harakat and the harakat).
##    If the weaked letters are reprsented as long harakat and striped from the word.
##    """
##    ## type : affix : uniformate affixes
##    ## type: verb uniformate verb, then treat last alef
##	word=normalize(word,type);
##	HARAKAT=(FATHA,DAMMA,KASRA,SUKUN);
##	shakl=u"";
##	word_nm=u""
##	i=0;
###	print "len word",len(word);
##	while i <len(word):
##		if word[i] not in HARAKAT:
##			word_nm+=word[i];
##			if i+1 < len(word) and word[i+1] in HARAKAT:
##				if word[i+1]==FATHA :
##					if i+2<len(word) and word[i+2]==ALEF and i+3<len(word) :
##						shakl+=ALEF_HARAKA;
###						shakl+=ALEF;
##						i+=3;
##					elif type=="verb" and  i+2<len(word) and word[i+2]==ALEF_MAKSURA :
###						shakl+=ALEF_HARAKA;
###						i+=3
##						shakl+=FATHA+FATHA;
##						word_nm+=YEH;
##						i+=3;
####معالجة حرف العلة في أخر الكلمةفي الفعل الناقص
####غذا كان الألف في آحر الفغعل الثلاثي يعوض بواو
####في الفعل غير الثلاثي يصبح ياء
##					elif type=="verb" and len(word_nm)==2 and i+2<len(word) and word[i+2]==ALEF and i+3>=len(word) :
###						shakl+=ALEF_HARAKA;
###						i+=3
####						print "len word_nm1 ",len(word_nm);
##						shakl+=FATHA+FATHA;
####  حالة الفعل عيا، أعيا، عيّا والتي يتحول إلى ياء بدلا عن واو
##						if word_nm[1]==YEH:
##						  word_nm+=YEH;
##						else :
##						  word_nm+=WAW;
###						print "len word_nm ",len(word_nm)
##						i+=3;
##					elif type=="verb" and  len(word_nm)>=3 and i+2<len(word) and word[i+2]==ALEF and i+3>=len(word) :
###						shakl+=ALEF_HARAKA;
###						i+=3
####						print "len word_nm44 ",len(word_nm);
##						shakl+=FATHA+FATHA;
##						word_nm+=YEH;
##						i+=3;
##					else :
##						shakl+=FATHA;
##						i+=2;
##				elif word[i+1]==DAMMA and i+2<len(word) and word[i+2]==WAW:
##					if i+3>=len(word) or word[i+3] not in HARAKAT:
##						shakl+=WAW_HARAKA;
##						i+=3;
##					else :
##						shakl+=DAMMA;
##						i+=2;
##				elif word[i+1]==KASRA and i+2<len(word) and word[i+2]==YEH:
##					if i+3>=len(word) or word[i+3] not in HARAKAT:
##						shakl+=YEH_HARAKA;
##						i+=3;
##					else :
##						shakl+=KASRA;
##						i+=2;
####					shakl+=YEH_HARAKA;
####					i+=3;
##				else :
##					shakl+=word[i+1];
##					i+=2;
####معالجة حالات الشدة، فك الإدغام
##			elif i+1 < len(word) and word[i+1] ==SHADDA:
##				shakl+=SUKUN;
##				word_nm+=word[i];
##				if i+2 < len(word) and word[i+2] in HARAKAT :
####					shakl+=word[i+2];
####					i+=3;
##					if i+3<len(word) and word[i+2]==FATHA and word[i+3]==ALEF:
##					    shakl+=ALEF_HARAKA;
##					    i+=4;
##					elif i+3<len(word) and word[i+2]==DAMMA and word[i+3]==WAW:
##					    shakl+=WAW_HARAKA
##					    i+=4;
##					elif i+3<len(word) and word[i+2]==KASRA and word[i+3]==YEH:
##					    shakl+=YEH_HARAKA
##					    i+=4;
##					else:
##					   shakl+=word[i+2];
##					   i+=3;
##				else :
##					shakl+=NOT_DEF_HARAKA;
##					i+=2;
##			elif i+1 < len(word) and  word[i+1] ==ALEF_MAKSURA:
##				shakl+=FATHA+NOT_DEF_HARAKA;
##				word_nm+=YEH;
##				i+=3;
##			elif  i+1 < len(word) and word[i+1] in HARAKAT :
##				shakl+=word[i+1];
##			else:
##				shakl+=NOT_DEF_HARAKA;
##				i+=1;
##		else: i+=1;
##	if len(word_nm)==len(shakl):
##		return (word_nm,shakl)
##	else: return (u"",u"");
###-----------------------------------------
###معالجة الحركات قبل الإخراج،
###
###
###------------------------------------------
##def standard_harakat(word):
##    k=0;
##    new_word=u"";
##    while k<len(word):
#### الحروف من دون العلة لا تؤخذ بيعين الاعتبار، كما لا تؤخذ إذا كانت في أول الكلمة
##       if k==0 or word[k] not in (ALEF,YEH,WAW,ALEF_MAKSURA):
##            new_word+=word[k];
##       else:
####إذا كان الحرف علة ولم يكن في أول الكلمة
####إذا كان ما قبله ليس حركة، ومابعده ليس حركة، أو انتهت الكلمة
##        if word[k-1] not in HARAKAT and (k+1>=len(word) or word[k+1] not in HARAKAT) :
##            if word[k]==ALEF:
##                new_word+=FATHA+ALEF;
##            elif word[k]==WAW :
##                new_word+=DAMMA+WAW;
##            elif word[k]==YEH:
##                new_word+=KASRA+YEH;
##            else:new_word+=word[k];
##        else:new_word+=word[k];
##       k+=1;
##    return new_word;
###--------------------------------------
##def geminating(word_nm,harakat):
##    """ treat geminatingcases
##    """
####    SUKUN_HARAKATE=(SUKUN,ALEF_HARAKA,YEH_HARAKA,WAW_HARAKA);
####    return word_nm,harakat;
##    new_word=u"";
##    new_harakat=u"";
##    i=0;
##    while i <len(word_nm):
### للإدغام يجب أن يكون الحرف الحالي مساويا للحرف التالي،
### كما يجب أن تكون حركة الحرف الحالي سكونا أو حركة قصيرة
##        if i>0 and i+1<len(word_nm) and word_nm[i+1]==SHADDA and harakat[i] in (SUKUN,FATHA,KASRA,DAMMA):
##            # treat geminating case
##            if  harakat[i]!=SUKUN and harakat[i+1]==SUKUN:
##                #no geminating
####the counter is incremented by one step only, to treat other possible geminating with the second letter
####                new_word+=word_nm[i]+word_nm[i+1];
####                new_harakat+=harakat[i]+harakat[i+1];
##                new_word+=word_nm[i];
##                word_nm=replace_pos(word_nm,word_nm[i],i+1)
##                new_harakat+=harakat[i];
##                i+=1;
####            elif  harakat[i]!=SUKUN and harakat[i+1]!=SUKUN:
####                #no geminating
######the counter is incremented by one step only, to treat other possible geminating with the second letter
######                new_word+=word_nm[i]+word_nm[i+1];
######                new_harakat+=harakat[i]+harakat[i+1];
####                new_word+=word_nm[i]+word_nm[i];
####                new_harakat+=harakat[i]+harakat[i+1];
####                i+=2;
##            elif  harakat[i]==SUKUN and harakat[i+1]==SUKUN:
##                #no geminating
####                new_word+=word_nm[i]+word_nm[i+1];
####                new_harakat+=FATHA+harakat[i+1];
##                new_word+=word_nm[i];
##                word_nm=replace_pos(word_nm,word_nm[i],i+1)
##                new_harakat+=FATHA;
##                i+=1;
##            else:
##
### عندما يكون الحرف السابق ساكنا فإنه يستعيعيض عن حركته بحركة الحرف الأول
##                if i-1>=0 and new_harakat[i-1]==SUKUN:
##                    new_word+=word_nm[i]+SHADDA;
##                    if harakat[i]!=SUKUN:
##                        new_harakat=new_harakat[:-1]+harakat[i]+NOT_DEF_HARAKA+harakat[i+1];
##                    else:
##                        new_harakat=new_harakat[:-1]+FATHA+NOT_DEF_HARAKA+harakat[i+1];
####                    new_harakat=new_harakat[:-1]+"*"+NOT_DEF_HARAKA+harakat[i+1];
#### يتم الإدغام إذا كان الحرف السابق ذو حركة طويلة
##                elif i-1>=0 and new_harakat[i-1]in (ALEF_HARAKA,WAW_HARAKA,YEH_HARAKA):
##                    new_word+=word_nm[i]+SHADDA;
##                    new_harakat+=NOT_DEF_HARAKA+harakat[i+1];
##                elif harakat[i]==SUKUN:
##                    new_word+=word_nm[i]+SHADDA;
##                    new_harakat+=NOT_DEF_HARAKA+harakat[i+1];
##                else:
#### مؤقت حتى يتم حل المشكلة
##                    new_word+=word_nm[i]+SHADDA;
##                    new_harakat+=NOT_DEF_HARAKA+harakat[i+1];
####TODO
#### منع الإدغام في بعض الحالات التي لا يمكن فيها الإدغام
####مثل حالة سكتتا ، أي الحرفات متحركان وما قبلهاما متحرك
#### تم حل هذه المشكلة من خلال خوارزمية التجانس بين التصريفات
##                    #no geminating
####                    new_word+=word_nm[i]+word_nm[i+1];
####                    new_harakat+=harakat[i]+harakat[i+1];
##                i+=2;
##        elif i>0 and i+1<len(word_nm) and word_nm[i+1]==word_nm[i] and harakat[i] ==SUKUN and harakat[i+1] in (FATHA, DAMMA, KASRA):
##            # treat geminating case
##            new_word+=word_nm[i]+SHADDA;
##            new_harakat+=NOT_DEF_HARAKA+harakat[i+1];
##            i+=2;
##        else :
##            new_word+=word_nm[i];
##            new_harakat+=harakat[i];
##            i+=1;
##    return (new_word,new_harakat);
##
###--------------------------------------
##def standard2(word_nm,harakat):
##    """ join the harakat and the letters to the give word in the standard script,
##    it return one strings ( the word with harakat and the harakat).
##    """
##    if len(word_nm)!=len(harakat):
####        print word_nm.encode("utf"), len(word_nm),write_harakat_in_full(harakat).encode("utf"), len(harakat);
##        return u"";
##    else:
##        word=u"";
##        i=0;
##        word_nm,harakat=geminating(word_nm,harakat);
##        if len(word_nm)!=len(harakat):
##            return u"";
#### حالة عدم الابتداء بسكون
####إذا كان الحرف الثاني مضموما  تكون الحركة الأولى مضمومة، وإلا تكون مكسورة
##        if len(harakat)!=0 and harakat[0]==SUKUN:
##            word_nm=ALEF+word_nm
##            if len(harakat)>=2 and harakat[1]in (DAMMA, WAW_HARAKA):
##                harakat=DAMMA+harakat
##            else:
##                harakat=KASRA+harakat
##
####        word_nm=tahmeez2(word_nm,harakat);
##        if len(word_nm)!=len(harakat):
##            return u"";
##        word_nm,harakat=homogenize(word_nm,harakat);
##
##        if len(word_nm)!=len(harakat):
##            return u"";
##        word_nm=tahmeez2(word_nm,harakat);
### table to convert uniforme harakat into standard harakat
##        written_haraka={
##        ALEF_HARAKA:FATHA+ALEF,
##        ALEF_WAW_HARAKA:FATHA+ALEF,
##        ALEF_YEH_HARAKA:FATHA+ALEF,
##        WAW_HARAKA:DAMMA+WAW,
##        YEH_HARAKA:KASRA+YEH,
##        ALTERNATIVE_YEH_HARAKA:KASRA+YEH,
##        NOT_DEF_HARAKA:'',
##        FATHA: FATHA,
##        DAMMA:DAMMA,
##        KASRA:KASRA,
##        SUKUN:SUKUN,
##        SHADDA:SHADDA
##        }
##        while i <len(word_nm):
##            # للعمل :
### هذه حالة الألف التي أصلها ياء
### وقد استغنينا عنها بأن جعلنا الحرف الناقص من الفعل الناقص حرفا تاما
####            if harakat[i]==ALEF_YEH_HARAKA  and i+1==len(word_nm):
####               	word+=word_nm[i]+FATHA+ALEF_MAKSURA;
####            el
##            if harakat[i]in written_haraka.keys():
##                word+=word_nm[i]+written_haraka[harakat[i]];
##            else:
##                word+=word_nm[i]+harakat[i];
##            i+=1;
### تحويل الياء الأخيرة غذا كانت مسوبقة بالفتحة إلى ألف مقصورة
### حالة الفعل الناقص
### حالة الفعل أعيا، أحيا
##        if word.endswith(FATHA+YEH+FATHA):
##            if not word.endswith(YEH+FATHA+YEH+FATHA) :
##                word=word[:-2]+ALEF_MAKSURA;
##            else :
##                word=word[:-2]+ALEF;
### حالة الفعل الناقص
###تحويل الواو الأخيرة المسبوقة بفتحة إلى ألف
##        elif word.endswith(FATHA+WAW+FATHA):
##        	word=word[:-2]+ALEF;
####-	تحويل همزة القطع على الألف بعدها فتحة وهمزة القطع على الألف بعدها سكون إلى ألف ممدودة
##
##	word=word.replace( u"%s%s%s"%(ALEF_HAMZA_ABOVE,FATHA,ALEF),ALEF_MADDA);
##	word=word.replace( u"%s%s"%(ALEF_MADDA,FATHA),ALEF_MADDA);
##	word=word.replace( u"%s%s"%(ALEF_MADDA,ALEF),ALEF_MADDA);
##	word=word.replace( u"%s%s%s%s"%(ALEF_HAMZA_ABOVE,FATHA,ALEF_HAMZA_ABOVE,SUKUN),ALEF_MADDA);
##	word=word.replace( u"%s%s%s%s"%(ALEF_HAMZA_ABOVE,FATHA,ALEF_HAMZA_ABOVE,FATHA),ALEF_MADDA);
##	word=word.replace( u"%s%s%s%s"%(ALEF,KASRA,HAMZA,SUKUN),ALEF+KASRA+YEH_HAMZA+SUKUN);
##	word=word.replace( u"%s%s%s%s"%(ALEF,DAMMA,HAMZA,SUKUN),ALEF+DAMMA+WAW_HAMZA+SUKUN);
##	word=word.replace( u"%s%s%s%s"%(ALEF_HAMZA_ABOVE,DAMMA,WAW_HAMZA,SUKUN),ALEF_HAMZA_ABOVE+DAMMA+WAW);
##	word=word.replace( u"%s%s%s%s"%(WAW_HAMZA,SUKUN,YEH_HAMZA,KASRA),YEH_HAMZA+SHADDA+KASRA);
##	word=word.replace( u"%s%s%s%s"%(WAW_HAMZA,SUKUN,ALEF_HAMZA_ABOVE,FATHA),ALEF_HAMZA_ABOVE+SHADDA+FATHA);
##	word=word.replace( u"%s%s%s%s"%(ALEF_HAMZA_ABOVE,SUKUN,YEH_HAMZA,KASRA),YEH_HAMZA+SHADDA+KASRA);
##	word=word.replace( u"%s%s%s%s%s"%(WAW,SUKUN,WAW_HAMZA,DAMMA,WAW),WAW+SUKUN+HAMZA+DAMMA+WAW);
##	word=word.replace( u"%s%s%s%s"%(YEH,SHADDA,FATHA,ALEF_MAKSURA),YEH+SHADDA+FATHA+ALEF);
##
####  معالجة ألف التفريق
##	word=word.replace( ALEF_WASLA,ALEF);
####  معالجة ألف  الوصل الزائدة عند إضافتها إلى أول الفعل المثال
##	word=word.replace( u"%s%s%s%s"%(ALEF,DAMMA,YEH,SUKUN),ALEF+DAMMA+WAW);
##
##
##	return word;
##
##
##
###--------------------------------------
### إعلال و إبدال الهمزة.
###--------------------------------------
##def tahmeez2(word_nm,harakat):
##    """ Transform hamza on the standard script. in entry the word without harakat and the harakat seperately
##    return the word with non uniform hamza
##
##    """
##    if len(word_nm)!=len(harakat):
##        return u"";
##    else:
##    	ha2=u"";
##    	#eliminate some altenative of HARAKAT to standard.
##    	for h in harakat:
##		if h==NOT_DEF_HARAKA: h=FATHA;
##		elif h==ALEF_YEH_HARAKA or h==ALEF_WAW_HARAKA:
##			h=ALEF_HARAKA;
##		ha2+=h;
##	harakat=ha2;
##        word=u"";
##       	HAMZAT= u"إأءئؤ";
##        for i in range(len(word_nm)):
##            if word_nm[i] !=HAMZA and word_nm[i] !=ALEF_HAMZA_ABOVE:
##                 word+=word_nm[i];
##            else:
##                if i==0:
##                    actual=harakat[i];
##                    swap= tab_tahmeez_initial[actual];
##                else:
##                    before=harakat[i-1];
##                    actual=harakat[i];
##                    if i+1<len(word_nm):
##                   	if before in tab_tahmeez_middle.keys() and actual in tab_tahmeez_middle[before].keys() :
##	                        swap= tab_tahmeez_middle[before][actual];
##	                else :
####	                	print (u"Middle : word %s in letter %s between '%s' and '%s'"%(word_nm,word_nm[i],before,actual)).encode("utf8");
##	                	swap=word_nm[i];
##                    else :
##                    	if before in tab_tahmeez_final.keys() and actual in tab_tahmeez_final[before].keys() :
##                        	swap= tab_tahmeez_final[before][actual];
##	                else :
####	                	print (u"Final :word %s in letter %s between '%s' and '%s'"%(word_nm,word_nm[i],before,actual)).encode("utf8");
##	                	swap=word_nm[i];
##            	word+=swap;
##	return word;
##
###--------------------------------------
##def treat_sukun2(word_nm,harakat,swaped_haraka=KASRA):
##    """ Treat the rencontre of sukun. in entry the word without harakat and the harakat seperately, and the probably haraka
##    return the new sequence of harakat
##
##    """
##    if len(word_nm)!=len(harakat):
##        return harakat;
##    else:
##        new_harakat=u"";
##        for i in range(len(word_nm)):
##            if harakat[i]==ALEF_HARAKA and i+1<len(harakat) and harakat[i+1]==SUKUN:
###  other conditions
### إذا كان حرف الألف ثانيا مثل خاف يقلب كسرة،أما إذا كان ثالثا أو رابعا فيصبح فتحة، مثل خاف لا تخف
##		if i+2<len(word_nm) and word_nm[i+1]==word_nm[i+2]:
##			new_harakat+=ALEF_HARAKA;
##      		elif i==0 :
##      		    new_harakat+=KASRA;
##      		else:
##      		    new_harakat+=FATHA;
##            elif harakat[i]==ALEF_YEH_HARAKA and i+1<len(harakat) and harakat[i+1]==SUKUN:
###  other conditions
##      		    new_harakat+=KASRA;
##            elif harakat[i]==ALEF_WAW_HARAKA and i+1<len(harakat) and harakat[i+1]==SUKUN:
###  other conditions
##      		    new_harakat+=DAMMA;
##            elif harakat[i]==WAW_HARAKA and i+1<len(harakat) and harakat[i+1]==SUKUN:
##                #  other conditions
##                new_harakat+=DAMMA;
##            elif harakat[i]==YEH_HARAKA and i+1<len(harakat) and harakat[i+1]==SUKUN:
##                #  other conditions
##                new_harakat+=KASRA;
##            elif harakat[i]==ALTERNATIVE_YEH_HARAKA and i+1<len(harakat) and harakat[i+1]==SUKUN:
##                #  other conditions
##                new_harakat+=DAMMA;
##            else :
##                new_harakat+=harakat[i];
##    return new_harakat;
##
###--------------------------------------#
### معالجة التحولات التي تطرا على الياء أو الوا في وسط الكلمة أو في اخرها
###
###
###---------------------------------------
##def homogenize(word_nm,harakat):
##    """ treat the jonction of WAW, YEH
##    """
##    if len(word_nm)!=len(harakat):
##        return (word_nm, harakat);
##    else:
##        new_harakat=u"";
##        new_word=u"";
##        i=0;
#### دراسة حالات الياء والواو قبل النهاية
##        while i<len(word_nm)-1:
##            if word_nm[i]==YEH:
###إذا كانت الياء ساكنة أو مكسورة (كسرا قصيرا أو طويلا)، وكان ما قبلها مكسورا، يأخذ ماقبلها كسرة طويلة
###مثال :
### بِ +يْ => بِي
###بِ +يِ  => بِي
###بِ +يي => بِي
##
##                if  (harakat[i]in(SUKUN,KASRA,YEH_HARAKA)) and i-1>=0 and harakat[i-1]==KASRA:
##                    new_harakat=new_harakat[:-1]+YEH_HARAKA
####تحويل الياء إلى واو ساكنة
###2 - إذا كانت الياء مضمومة (ضما قصيرا أو طويلا)، وكان ما قبلها مفتوحا، تتحول الياء إلى واو ساكنة.
###مثال :
### بَ +يُ => بَِوْ
###بَ +يو  => بَوْ
##
##                elif (harakat[i] in (DAMMA, WAW_HARAKA))and i-1>=0 and harakat[i-1]==FATHA:
##                    new_harakat+=SUKUN
##                    new_word+=WAW;
####إذا كانت ساكنة، وماقبلها مضموما، ولم يكن ما بعدها ياء، أخذ ما قبلها ضمة طويلة.
####مثال :
#### بُ +يُت =>بُوت
##
##                elif  (harakat[i] in(SUKUN)) and i-1>=0 and harakat[i-1]==DAMMA and (i+1<len(word_nm) and word_nm[i+1]!=YEH):
##                    new_harakat=new_harakat[:-1]+WAW_HARAKA
##
##                elif (harakat[i] in (YEH_HARAKA))and i-1>=0 and harakat[i-1]==FATHA:
##                    new_harakat+=SUKUN
##                    new_word+=YEH;
##                elif  (harakat[i] in(WAW_HARAKA)) and i-1>=0 and harakat[i-1]==KASRA:
##                    new_harakat=new_harakat[:-1]+WAW_HARAKA
##
##                else :
##                    new_harakat+=harakat[i];
##                    new_word+=word_nm[i];
##            elif word_nm[i]==WAW:
##                if (harakat[i] in(SUKUN,DAMMA,WAW_HARAKA))and i-1>=0 and harakat[i-1]==DAMMA:
##                    new_harakat=new_harakat[:-1]+WAW_HARAKA
####تحويل الواو المضمومة  أو الطويلة إلى واو ساكنة
##                elif (harakat[i] in (DAMMA, WAW_HARAKA))and i-1>=0 and harakat[i-1]==FATHA:
##                    new_harakat+=SUKUN
##                    new_word+=word_nm[i];
##                else :
##                    new_harakat+=harakat[i];
##                    new_word+=word_nm[i];
##            else:
##                new_harakat+=harakat[i];
##                new_word+=word_nm[i];
##            i+=1;
#### دراسة حالة الحرف الأخير
####        new_harakat+=harakat[i];
####        new_word+=word_nm[i];
##        if word_nm[i]==YEH:
##            if  (harakat[i] in(KASRA,YEH_HARAKA,DAMMA)) and i-1>=0 and harakat[i-1]==KASRA:
##                new_harakat=new_harakat[:-1]+YEH_HARAKA
##            elif (harakat[i]==SUKUN):
##                pass;
##            elif  (harakat[i] in(KASRA,DAMMA,FATHA)) and i-1>=0 and harakat[i-1]==FATHA:
##                new_harakat+=NOT_DEF_HARAKA
##                new_word+=ALEF_MAKSURA;
##            elif  (harakat[i] in(WAW_HARAKA)) and i-1>=0 and harakat[i-1]==KASRA:
##                new_harakat=new_harakat[:-1]+WAW_HARAKA
##            else :
##                new_harakat+=harakat[i];
##                new_word+=word_nm[i];
##        elif word_nm[i]==WAW:
##            if (harakat[i] in(DAMMA,WAW_HARAKA,KASRA))and i-1>=0 and harakat[i-1]==DAMMA:
##                new_harakat=new_harakat[:-1]+WAW_HARAKA
##            elif (harakat[i] in(ALEF_HARAKA))and i-1>=0 and harakat[i-1]==DAMMA:
####                pass;
##                new_harakat=new_harakat[:-1]+YEH_HARAKA
##            elif (harakat[i]==SUKUN):
##                pass;
####                new_harakat=new_harakat[:-1]+WAW_HARAKA
##            else :
##                new_harakat+=harakat[i];
##                new_word+=word_nm[i];
##        else:
##            new_harakat+=harakat[i];
##            new_word+=word_nm[i];
##        return (new_word, new_harakat);
##
###------------------------------------------------------------------------
### Function to determin if the first TEH in the verb is not original
### ترجع إذا كانت التاء الأولى في الفعل غير أصلية
###-------------------------------------------------------------------------------
##def is_teh_zaida(verb_normalized_unvocalized):
### التاء الزائدة
### الفعل يكون منتظما،
### تعتبر الشدة حرف
### الفعل منزوع الحركات
### verb must be  normalized
### SHADDA is considered as a Letter
### verb is not vocalized
### a Teh is added, if the verb is more than 5 letters lenght and starts by Teh
### ألأوزان المعنية هي
### تفاعل، تفعلل، تفعّل
### الأوزان تفاعّ => تفاعل.
##    verb=verb_normalized_unvocalized;
##    if len(verb)<5 or not verb.startswith(TEH) :return False;
##    elif len(verb)>=5 and verb.startswith(TEH):
##        return True;
##    else : return False;
##
###------------------------------------------------------------------------
### Function to determin if the first HAMZA in the verb is not original
### ترجع إذا كانت الهمزة الأولى في الفعل غير أصلية
###-------------------------------------------------------------------------------
##def is_hamza_zaida(verb_normalized_unvocalized):
### الهمزة الزائدة
### الفعل يكون منتظما،
### تعتبر الشدة حرف
### الفعل منزوع الحركات
### verb must be  normalized
### SHADDA is considered as a Letter
### verb is not vocalized
### a hamza is not original ,
### if the lenght of verb is exactely 4 letters and starts by hamza
### and it is in the AF3Al wazn and not FA33al or FAA3la
### ألوزن المعني هو أفعل
### الأوزان غير المعنية هي فاعل وفعّل
### الأوزان المشتقة هي أفعّ من أفعل
### الخلاصة أن يكون الفعل رباعيا، حرفه الأول همزة
### ولا يكون حرفه الثاني ألف، لمنع الوزن فاعل
### ولا يكون حرفه الثالث شدة، لمنع الوزن فعّل
##    verb=verb_normalized_unvocalized;
##    if len(verb)!=4 or  not verb.startswith(HAMZA) :return False;
##    elif len(verb)==4 and verb.startswith(HAMZA) and verb[1]!=ALEF and verb[2]!=SHADDA:
##        return True;
##    else : return False;
###------------------------------------------------
### get the bab sarf harakat by the bab sarf number
### ترجع حركتي الماضي والمضارع حسب باب الصرف
###
###------------------------------------------------
##def get_bab_sarf_harakat(number):
##    if number<1 or number>6:
##        return None;
##    elif number==1:
##        return (FATHA,DAMMA);
##    elif number==2:
##        return (FATHA,FATHA);
##    elif number==3:
##        return (FATHA,KASRA);
##    elif number==4:
##        return (KASRA,FATHA);
##    elif number==5:
##        return (DAMMA,DAMMA);
##    elif number==6:
##        return (KASRA,KASRA);
###------------------------------------------------
### get the bab sarf number by past and future harakat
### ترجع رقم باب الصرف للأفعال الثلاثية
###
###------------------------------------------------
##def get_bab_sarf_number(past_haraka,future_haraka):
##    if past_haraka==FATHA and future_haraka==DAMMA:
##        return 1;
##    elif past_haraka==FATHA and future_haraka==FATHA:
##        return 2;
##    elif past_haraka==FATHA and future_haraka==KASRA:
##        return 3;
##    elif past_haraka==KASRA and future_haraka==FATHA:
##        return 4;
##    elif past_haraka==DAMMA and future_haraka==DAMMA:
##        return 5;
##    elif past_haraka==KASRA and future_haraka==KASRA:
##        return 6;
##    else:
##        return 0;
##
##def is_irregular_verb(verb_letters,verb_marks,future_type):
##    if len(verb_letters)!=3: return False;
##    else:
##        past=verb_marks[1];
##        return True;
##    verb=ar_st
##    return False;
##def write_harakat_in_full(harakat):
##    full=u"";
##    tab_harakat={
##    FATHA:u"فتحة",
##    DAMMA:u"ضمة",
##    KASRA:u"كسرة",
##    SUKUN:u"سكون",
##    ALEF_HARAKA:u"ألف",
##    WAW_HARAKA:u"واو",
##    YEH_HARAKA:u"ياء",
##    ALEF_YEH_HARAKA:u"ى",
##    ALEF_WAW_HARAKA:u"و",
##    ALEF_YEH_ALTERNATIVE:u"ئ",
##    }
##    for c in harakat:
##        if c in tab_harakat.keys():
##            full+=u'-'+tab_haraka[c];
##        else:
##            full+=u"*";
##    return full;
##def get_past_harakat_by_babsarf(vtype):
##	marks=KASRA+KASRA+KASRA;
##	if vtype in ('1','2','3'):
##	   marks=FATHA+FATHA+FATHA
##	elif vtype in ('4','6'):
##	   marks=FATHA+KASRA+FATHA
##	elif vtype=='5':
##	   marks=FATHA+DAMMA+FATHA
##	return marks;
##def get_future_harakat_by_babsarf(vtype):
##	marks=KASRA+KASRA+KASRA;
##	if vtype in ('1','2','3'):
##	   marks=FATHA+FATHA+FATHA
##	elif vtype in ('4','6'):
##	   marks=FATHA+KASRA+FATHA
##	elif vtype=='5':
##	   marks=FATHA+DAMMA+FATHA
##	return marks;
##
##def get_future_haraka_by_babsarf(vtype):
##	if vtype=='1': return DAMMA;
##	elif vtype in ('2','6'): return KASRA;
##	elif vtype in ('3','4'): return FATHA;
##	elif vtype in ('1','5'): return DAMMA;
##	else: return "";
##

﻿#!/usr/bin/python
# -*- coding=utf-8 -*-
##from analex import *

import sys
import re
import  getopt
import os
import string
from ar_ctype import *
from ar_stowords import *
scriptname = os.path.splitext(os.path.basename(sys.argv[0]))[0]
scriptversion = '0.1'
AuthorName="Taha Zerrouki"
def usage():
# "Display usage options"
	print "(C) CopyLeft 2007, %s"%AuthorName
	print "Usage: %s -f filename [OPTIONS]" % scriptname
#"Display usage options"
	print "\t[-h | --help]\t\toutputs this usage message"
	print "\t[-V | --version]\tprogram version"
	print "\t[-f | --file= filename]\tinput file to %s"%scriptname
	print "\r\nThis program is licensed under the GPL License\n"

def grabargs():
#  "Grab command-line arguments"
	all = False;
	segmentation=False;
	dictionarybased=False;
	templatesearch=False;
	rootextraction=False;
	vocalized=False;
	convert=False;
	fname = ''

	if not sys.argv[1:]:
		usage()
		sys.exit(0)
	try:
		opts, args = getopt.getopt(sys.argv[1:], "hV:f:",
                               ["help", "version",
                                 "file="],)
	except getopt.GetoptError:
		usage()
		sys.exit(0)
	for o, val in opts:
		if o in ("-h", "--help"):
			usage()
			sys.exit(0)
		if o in ("-V", "--version"):
			print scriptversion
			sys.exit(0)
		if o in ("-f", "--file"):
			fname = val
	return fname

def main():

	filename=grabargs()
	print "file name ",filename
#ToDo1 ref
	if (not filename):
		usage()
		sys.exit(0)
	option="";
	try:
		fl=open(filename);
	except :
		print " Error :No such file or directory: %s" % filename
		return None;
	line=fl.readline().decode("utf8");
	text=u""
	limit=1000;
	counter=0;
	counter_match=0;
	counter_stop_words=0;
	counter_verb=0;
	counter_noun=0;
	while line and counter<limit:
##		text=" ".join([text,chomp(line)])
		line=fl.readline().decode("utf8");
		if not line.startswith("#"):
		    listword=line.split(";");
    		if len(listword)>=9:
    		  word=ar_strip_marks(listword[0]);
    		  type_word=listword[1];
    		  class_word=listword[2];
    		  has_conjuction=listword[3];
    		  has_definition=listword[4];
    		  has_preposition=listword[5];
    		  has_pronoun=listword[6];
    		  has_interrog=listword[7];
    		  if has_conjuction=="*":
    		      has_conjuction=False;
    		  else:
    		      has_conjuction=True;
    		  if has_definition=="*":
    		      has_definition=False;
    		  else:
    		      has_definition=True;

    		  if has_preposition=="*":
    		      has_preposition=False;
    		  else:
    		      has_preposition=True;

    		  if has_pronoun=="*":
    		      has_pronoun=False;
    		  else:
    		      has_pronoun=True;
    		  if has_interrog=="*":
    		      has_interrog=False;
    		  else:
    		      has_interrog=True;
    		  list0=generate_allforms(word,has_pronoun,has_conjuction,has_preposition,has_definition,has_interrog);
    		  for l in list0:
    		      print standardize_form(l).encode("utf8"),
    		      print "\t",
    		      print l.encode("utf8");
		counter+=1
if __name__ == "__main__":
  main()







